var bananaImage, obstacleImage, obstacleGroup, bg, score, banana, player, bg, ground, score, foodGroup;

function preload() {
  backImage = loadImage("jungle.jpg");
  player_running = loadAnimation("Monkey_01.png", "Monkey_02.png", "Monkey_03.png", "Monkey_04.png", "Monkey_05.png", "Monkey_06.png", "Monkey_07.png", "Monkey_08.png", "Monkey_09.png", "Monkey_10.png")
  bananaImage = loadImage("banana.png")
  obstacle_img = loadImage("stone.png")
}

function setup() {
  createCanvas(400, 400);
  player = createSprite(40, 350, 10, 10);
  player.addAnimation("Player", player_running);
  player.scale = 0.09;
  ground = createSprite(200, 390, 400, 25);
  ground.visible = false;
 obstacleGroup = createGroup();
  foodGroup = createGroup();
score= 0;


}

function draw() {
  background(backImage);
    drawSprites();

  
  player.velocityY = player.velocityY + 0.55
  player.collide(ground);

  console.log(player.y)
  if(player.y > 349 && keyDown("space") ){
    player.velocityY = -10
  }
  
  stroke("white");
  textSize(20);
  fill("white");
  score = score + Math.round(getFrameRate() / 60.5);
  text("Survival time:" + score, 35, 50);

    if (obstacleGroup.isTouching(player)){
  player.scale=0.08;
 }
  if (foodGroup.isTouching(player)) {
    score = score +2;
    player.scale = 0.09;  
    foodGroup.destroyEach();
  }

  spawnBananas();
  obstaclesGroup();
}

function spawnBananas() {
  if (World.frameCount % 120 === 0) {
    banana = createSprite(450, 200, 10, 10);
    banana.addImage("B1", bananaImage);
    banana.scale = 0.04
    banana.y = random(240, 300);
    banana.velocityX = -3;
    banana.depth = player.depth;
    player.depth = player.depth + 1;
    banana.lifetime = 160;
    foodGroup.add(banana);
  }
}

function obstaclesGroup() {
  if (World.frameCount % 80 === 0) {
    var rock = createSprite(410, 360, 10, 10);
    rock.addImage("R1", obstacle_img)
    rock.scale = 0.1;
    rock.velocityX = -3;
    rock.lifetime = 160;
    obstacleGroup.add(rock);
   
  }
}